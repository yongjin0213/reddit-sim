Name: Yongjin Lee
NetID: yl2889

Challenges Attempted: (Tier I, Tier II, Tier III)

Difficulties:
Comments:
